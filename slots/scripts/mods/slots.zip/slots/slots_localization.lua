return {
	mod_description = {
		en = "slots description",
	},
}
