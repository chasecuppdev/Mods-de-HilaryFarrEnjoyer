local mod = get_mod("slots")

return {
	name = "slots",
	description = mod:localize("mod_description"),
	is_togglable = true,
}
